/* generated configuration header file - do not edit */
#ifndef R_DAC_B_CFG_H_
#define R_DAC_B_CFG_H_
#define DAC_B_CFG_PARAM_CHECKING_ENABLE (BSP_CFG_PARAM_CHECKING_ENABLE)
#endif /* R_DAC_B_CFG_H_ */
