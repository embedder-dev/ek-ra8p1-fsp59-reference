/* generated HAL header file - do not edit */
#ifndef HAL_DATA_H_
#define HAL_DATA_H_
#include <stdint.h>
#include "bsp_api.h"
#include "common_data.h"
#include "r_dac_b.h"
#include "r_dac_api.h"
FSP_HEADER
extern const dac_instance_t g_dac_b0;
extern dac_b_instance_ctrl_t g_dac_b0_ctrl;
extern const dac_cfg_t g_dac_b0_cfg;
void hal_entry(void);
void g_hal_init(void);
FSP_FOOTER
#endif /* HAL_DATA_H_ */
