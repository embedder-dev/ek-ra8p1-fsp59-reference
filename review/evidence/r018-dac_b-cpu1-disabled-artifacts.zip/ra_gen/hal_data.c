/* generated HAL source file - do not edit */
#include "hal_data.h"
dac_b_instance_ctrl_t g_dac_b0_ctrl;
const dac_b_extended_cfg_t g_dac_b0_ext_cfg =
{
    .data_format = DAC_DATA_FORMAT_FLUSH_RIGHT,
    .voltage_mode = DAC_B_VOLTAGE_NORMAL,
    .output = DAC_B_OUTPUT_PIN,
    .trigger = (0 == NULL) ? DAC_B_TRIGGER_SOFTWARE : DAC_B_TRIGGER_ELC,
#if defined(NULL)
    .p_pair = NULL,
#else
    .p_pair = &NULL,
#endif
    .timeout = 1000000,
    .calibration_preloaded = false,
};
const dac_cfg_t g_dac_b0_cfg =
{
    .channel = 0,
    .ad_da_synchronized = false,
    .p_extend = &g_dac_b0_ext_cfg,
};
const dac_instance_t g_dac_b0 =
{
    .p_ctrl = &g_dac_b0_ctrl,
    .p_cfg = &g_dac_b0_cfg,
    .p_api = &g_dac_on_dac_b,
};
void g_hal_init(void) {
g_common_init();
}
