/* generated HAL source file - do not edit */
#include "hal_data.h"
mram_instance_ctrl_t g_mram0_ctrl;
const mram_extended_cfg_t g_mram0_ext_cfg =
{
    .write_window_start = 0,
    .write_window_end = 0,
    .timeout = 1000000,
    .enable_extra_commands = false,
};
const flash_cfg_t g_mram0_cfg =
{
    .data_flash_bgo = false,
    .p_callback = NULL,
#if defined(NULL)
    .p_context = NULL,
#else
    .p_context = &NULL,
#endif
    .p_extend = &g_mram0_ext_cfg,
    .irq = FSP_INVALID_VECTOR,
    .err_irq = FSP_INVALID_VECTOR,
    .ipl = BSP_IRQ_DISABLED,
    .err_ipl = BSP_IRQ_DISABLED,
};
const flash_instance_t g_mram0 =
{
    .p_ctrl = &g_mram0_ctrl,
    .p_cfg = &g_mram0_cfg,
    .p_api = &g_flash_on_mram,
};
void g_hal_init(void) {
g_common_init();
}
