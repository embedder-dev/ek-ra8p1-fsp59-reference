/* generated HAL header file - do not edit */
#ifndef HAL_DATA_H_
#define HAL_DATA_H_
#include <stdint.h>
#include "bsp_api.h"
#include "common_data.h"
#include "r_mram.h"
#include "r_flash_api.h"
FSP_HEADER
extern const flash_instance_t g_mram0;
extern mram_instance_ctrl_t g_mram0_ctrl;
extern const flash_cfg_t g_mram0_cfg;
#ifndef NULL
void NULL(flash_callback_args_t * p_args);
#endif
void hal_entry(void);
void g_hal_init(void);
FSP_FOOTER
#endif /* HAL_DATA_H_ */
