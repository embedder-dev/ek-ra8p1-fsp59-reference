/* generated configuration header file - do not edit */
#ifndef R_MRAM_CFG_H_
#define R_MRAM_CFG_H_
#define MRAM_CFG_PARAM_CHECKING_ENABLE (BSP_CFG_PARAM_CHECKING_ENABLE)
#endif /* R_MRAM_CFG_H_ */
