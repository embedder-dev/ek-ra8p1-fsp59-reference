/* generated HAL source file - do not edit */
#include "hal_data.h"
pdm_instance_ctrl_t g_pdm0_ctrl;
pdm_extended_cfg_t const g_pdm0_ext_cfg =
{
    .input = PDM_INPUT_RISING,
    .sample_format = PDM_SAMPLE_FORMAT_20_BITS,
    .clock_div = 0,
    .sinc_order = 4,
    .high_pass_shift = 0,
    .compensation_shift = 0,
    .low_pass_shift = 0,
    .fifo_threshold = 4,
    .microphone_delay_us = 0,
    .error_enable = 0,
    .short_circuit_low = 0,
    .short_circuit_high = 0,
    .lower_limit = 0x80000,
    .upper_limit = 0x7FFFF,
#if defined(NULL)
    .p_coefficients = NULL,
#else
    .p_coefficients = &NULL,
#endif
};
pdm_cfg_t const g_pdm0_cfg =
{
    .p_extend = &g_pdm0_ext_cfg,
    .channel = 2,
    .ipl = (12),
    .p_callback = NULL,
#if defined(NULL)
    .p_context = NULL,
#else
    .p_context = &NULL,
#endif
#if defined(VECTOR_NUMBER_PDM_DAT2)
    .dat_irq = VECTOR_NUMBER_PDM_DAT2,
#else
    .dat_irq = FSP_INVALID_VECTOR,
#endif
#if defined(VECTOR_NUMBER_PDM_ERR2)
    .err_irq = VECTOR_NUMBER_PDM_ERR2,
#else
    .err_irq = FSP_INVALID_VECTOR,
#endif
};
pdm_instance_t const g_pdm0 = { .p_ctrl = &g_pdm0_ctrl, .p_cfg = &g_pdm0_cfg, .p_api = &g_pdm_on_pdm };
void g_hal_init(void) {
g_common_init();
}
