/* generated HAL header file - do not edit */
#ifndef HAL_DATA_H_
#define HAL_DATA_H_
#include <stdint.h>
#include "bsp_api.h"
#include "common_data.h"
#include "r_pdm.h"
FSP_HEADER
extern pdm_instance_t const g_pdm0;
extern pdm_instance_ctrl_t g_pdm0_ctrl;
extern pdm_cfg_t const g_pdm0_cfg;
#ifndef NULL
void NULL(pdm_callback_args_t * p_args);
#endif
#ifndef NULL
extern pdm_coefficients_t const NULL;
#endif
void hal_entry(void);
void g_hal_init(void);
FSP_FOOTER
#endif /* HAL_DATA_H_ */
