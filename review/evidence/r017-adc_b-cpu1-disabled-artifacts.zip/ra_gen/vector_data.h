/* generated vector header file - do not edit */
        #ifndef VECTOR_DATA_H
        #define VECTOR_DATA_H
        #ifdef __cplusplus
        extern "C" {
        #endif
                /* Number of interrupts allocated */
        #ifndef VECTOR_DATA_IRQ_COUNT
        #define VECTOR_DATA_IRQ_COUNT    (18)
        #endif
        /* ISR prototypes */
        void adc_b_limclpi_isr(void);
        void adc_b_err0_isr(void);
        void adc_b_err1_isr(void);
        void adc_b_resovf0_isr(void);
        void adc_b_resovf1_isr(void);
        void adc_b_calend0_isr(void);
        void adc_b_calend1_isr(void);
        void adc_b_adi0_isr(void);
        void adc_b_adi1_isr(void);
        void adc_b_adi2_isr(void);
        void adc_b_adi3_isr(void);
        void adc_b_adi4_isr(void);
        void adc_b_fifoovf_isr(void);
        void adc_b_fiforeq0_isr(void);
        void adc_b_fiforeq1_isr(void);
        void adc_b_fiforeq2_isr(void);
        void adc_b_fiforeq3_isr(void);
        void adc_b_fiforeq4_isr(void);

        /* Vector table allocations */
        #define VECTOR_NUMBER_ADC_LIMCLPI ((IRQn_Type) 0) /* ADC_LIMCLPI */
        #define ADC_LIMCLPI_IRQn          ((IRQn_Type) 0) /* ADC_LIMCLPI */
        #define VECTOR_NUMBER_ADC_ERR0 ((IRQn_Type) 1) /* ADC_ERR0 */
        #define ADC_ERR0_IRQn          ((IRQn_Type) 1) /* ADC_ERR0 */
        #define VECTOR_NUMBER_ADC_ERR1 ((IRQn_Type) 2) /* ADC_ERR1 */
        #define ADC_ERR1_IRQn          ((IRQn_Type) 2) /* ADC_ERR1 */
        #define VECTOR_NUMBER_ADC_RESOVF0 ((IRQn_Type) 3) /* ADC_RESOVF0 */
        #define ADC_RESOVF0_IRQn          ((IRQn_Type) 3) /* ADC_RESOVF0 */
        #define VECTOR_NUMBER_ADC_RESOVF1 ((IRQn_Type) 4) /* ADC_RESOVF1 */
        #define ADC_RESOVF1_IRQn          ((IRQn_Type) 4) /* ADC_RESOVF1 */
        #define VECTOR_NUMBER_ADC_CALEND0 ((IRQn_Type) 5) /* ADC_CALEND0 */
        #define ADC_CALEND0_IRQn          ((IRQn_Type) 5) /* ADC_CALEND0 */
        #define VECTOR_NUMBER_ADC_CALEND1 ((IRQn_Type) 6) /* ADC_CALEND1 */
        #define ADC_CALEND1_IRQn          ((IRQn_Type) 6) /* ADC_CALEND1 */
        #define VECTOR_NUMBER_ADC_ADI0 ((IRQn_Type) 7) /* ADC_ADI0 */
        #define ADC_ADI0_IRQn          ((IRQn_Type) 7) /* ADC_ADI0 */
        #define VECTOR_NUMBER_ADC_ADI1 ((IRQn_Type) 8) /* ADC_ADI1 */
        #define ADC_ADI1_IRQn          ((IRQn_Type) 8) /* ADC_ADI1 */
        #define VECTOR_NUMBER_ADC_ADI2 ((IRQn_Type) 9) /* ADC_ADI2 */
        #define ADC_ADI2_IRQn          ((IRQn_Type) 9) /* ADC_ADI2 */
        #define VECTOR_NUMBER_ADC_ADI3 ((IRQn_Type) 10) /* ADC_ADI3 */
        #define ADC_ADI3_IRQn          ((IRQn_Type) 10) /* ADC_ADI3 */
        #define VECTOR_NUMBER_ADC_ADI4 ((IRQn_Type) 11) /* ADC_ADI4 */
        #define ADC_ADI4_IRQn          ((IRQn_Type) 11) /* ADC_ADI4 */
        #define VECTOR_NUMBER_ADC_FIFOOVF ((IRQn_Type) 12) /* ADC_FIFOOVF */
        #define ADC_FIFOOVF_IRQn          ((IRQn_Type) 12) /* ADC_FIFOOVF */
        #define VECTOR_NUMBER_ADC_FIFOREQ0 ((IRQn_Type) 13) /* ADC_FIFOREQ0 */
        #define ADC_FIFOREQ0_IRQn          ((IRQn_Type) 13) /* ADC_FIFOREQ0 */
        #define VECTOR_NUMBER_ADC_FIFOREQ1 ((IRQn_Type) 14) /* ADC_FIFOREQ1 */
        #define ADC_FIFOREQ1_IRQn          ((IRQn_Type) 14) /* ADC_FIFOREQ1 */
        #define VECTOR_NUMBER_ADC_FIFOREQ2 ((IRQn_Type) 15) /* ADC_FIFOREQ2 */
        #define ADC_FIFOREQ2_IRQn          ((IRQn_Type) 15) /* ADC_FIFOREQ2 */
        #define VECTOR_NUMBER_ADC_FIFOREQ3 ((IRQn_Type) 16) /* ADC_FIFOREQ3 */
        #define ADC_FIFOREQ3_IRQn          ((IRQn_Type) 16) /* ADC_FIFOREQ3 */
        #define VECTOR_NUMBER_ADC_FIFOREQ4 ((IRQn_Type) 17) /* ADC_FIFOREQ4 */
        #define ADC_FIFOREQ4_IRQn          ((IRQn_Type) 17) /* ADC_FIFOREQ4 */
        /* The number of entries required for the ICU vector table. */
        #define BSP_ICU_VECTOR_NUM_ENTRIES (18)

        #ifdef __cplusplus
        }
        #endif
        #endif /* VECTOR_DATA_H */
