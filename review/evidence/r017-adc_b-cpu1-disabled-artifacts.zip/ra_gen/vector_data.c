/* generated vector source file - do not edit */
        #include "bsp_api.h"
        /* Do not build these data structures if no interrupts are currently allocated because IAR will have build errors. */
        #if VECTOR_DATA_IRQ_COUNT > 0
        BSP_DONT_REMOVE const fsp_vector_t g_vector_table[BSP_ICU_VECTOR_NUM_ENTRIES] BSP_PLACE_IN_SECTION(BSP_SECTION_APPLICATION_VECTORS) =
        {
                        [0] = adc_b_limclpi_isr, /* ADC_LIMCLPI */
            [1] = adc_b_err0_isr, /* ADC_ERR0 */
            [2] = adc_b_err1_isr, /* ADC_ERR1 */
            [3] = adc_b_resovf0_isr, /* ADC_RESOVF0 */
            [4] = adc_b_resovf1_isr, /* ADC_RESOVF1 */
            [5] = adc_b_calend0_isr, /* ADC_CALEND0 */
            [6] = adc_b_calend1_isr, /* ADC_CALEND1 */
            [7] = adc_b_adi0_isr, /* ADC_ADI0 */
            [8] = adc_b_adi1_isr, /* ADC_ADI1 */
            [9] = adc_b_adi2_isr, /* ADC_ADI2 */
            [10] = adc_b_adi3_isr, /* ADC_ADI3 */
            [11] = adc_b_adi4_isr, /* ADC_ADI4 */
            [12] = adc_b_fifoovf_isr, /* ADC_FIFOOVF */
            [13] = adc_b_fiforeq0_isr, /* ADC_FIFOREQ0 */
            [14] = adc_b_fiforeq1_isr, /* ADC_FIFOREQ1 */
            [15] = adc_b_fiforeq2_isr, /* ADC_FIFOREQ2 */
            [16] = adc_b_fiforeq3_isr, /* ADC_FIFOREQ3 */
            [17] = adc_b_fiforeq4_isr, /* ADC_FIFOREQ4 */
        };
        #if BSP_FEATURE_ICU_HAS_IELSR
        const bsp_interrupt_event_t g_interrupt_event_link_select[BSP_ICU_VECTOR_NUM_ENTRIES] =
        {
            [0] = BSP_PRV_VECT_ENUM(EVENT_ADC_LIMCLPI,GROUP0), /* ADC_LIMCLPI */
            [1] = BSP_PRV_VECT_ENUM(EVENT_ADC_ERR0,GROUP1), /* ADC_ERR0 */
            [2] = BSP_PRV_VECT_ENUM(EVENT_ADC_ERR1,GROUP2), /* ADC_ERR1 */
            [3] = BSP_PRV_VECT_ENUM(EVENT_ADC_RESOVF0,GROUP3), /* ADC_RESOVF0 */
            [4] = BSP_PRV_VECT_ENUM(EVENT_ADC_RESOVF1,GROUP4), /* ADC_RESOVF1 */
            [5] = BSP_PRV_VECT_ENUM(EVENT_ADC_CALEND0,GROUP5), /* ADC_CALEND0 */
            [6] = BSP_PRV_VECT_ENUM(EVENT_ADC_CALEND1,GROUP6), /* ADC_CALEND1 */
            [7] = BSP_PRV_VECT_ENUM(EVENT_ADC_ADI0,GROUP7), /* ADC_ADI0 */
            [8] = BSP_PRV_VECT_ENUM(EVENT_ADC_ADI1,GROUP0), /* ADC_ADI1 */
            [9] = BSP_PRV_VECT_ENUM(EVENT_ADC_ADI2,GROUP1), /* ADC_ADI2 */
            [10] = BSP_PRV_VECT_ENUM(EVENT_ADC_ADI3,GROUP2), /* ADC_ADI3 */
            [11] = BSP_PRV_VECT_ENUM(EVENT_ADC_ADI4,GROUP3), /* ADC_ADI4 */
            [12] = BSP_PRV_VECT_ENUM(EVENT_ADC_FIFOOVF,GROUP4), /* ADC_FIFOOVF */
            [13] = BSP_PRV_VECT_ENUM(EVENT_ADC_FIFOREQ0,GROUP5), /* ADC_FIFOREQ0 */
            [14] = BSP_PRV_VECT_ENUM(EVENT_ADC_FIFOREQ1,GROUP6), /* ADC_FIFOREQ1 */
            [15] = BSP_PRV_VECT_ENUM(EVENT_ADC_FIFOREQ2,GROUP7), /* ADC_FIFOREQ2 */
            [16] = BSP_PRV_VECT_ENUM(EVENT_ADC_FIFOREQ3,GROUP0), /* ADC_FIFOREQ3 */
            [17] = BSP_PRV_VECT_ENUM(EVENT_ADC_FIFOREQ4,GROUP1), /* ADC_FIFOREQ4 */
        };
        #endif
        #endif
